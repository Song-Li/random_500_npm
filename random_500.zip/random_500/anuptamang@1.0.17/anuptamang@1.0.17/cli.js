#!/usr/bin/env node
require('./installer.js').interpret(process.argv);