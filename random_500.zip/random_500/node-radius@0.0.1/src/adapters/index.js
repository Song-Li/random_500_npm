'use strict';

module.exports = {
    express: require('./express.js')
};
