module.exports = {
    jade: require('./jade'),
    stylus: require('./stylus')
};