module.exports = {
    'clean-css': require('./clean-css'),
    'uglify-js': require('./uglify-js')
};