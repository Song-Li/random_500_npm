/** file1.js */
function file1() {}