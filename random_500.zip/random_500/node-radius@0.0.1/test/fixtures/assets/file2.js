/** file2.js */
function file2() {}
