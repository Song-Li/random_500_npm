Description
===========

Crossmon-cpu is a cpu usage gatering module for crossmon-collect.


Requirements
============

* [node.js](http://nodejs.org/) -- v0.8.0 or newer
* crossmon-collect

Installation
============

    npm install crossmon-cpu
		
