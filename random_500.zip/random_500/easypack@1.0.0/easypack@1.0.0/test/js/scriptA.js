/**!
 * Some copyright text
 */
$('#a').text("Script A checking in");