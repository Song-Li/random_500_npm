var fs = require('fs');
var qqmail = require('./index.js');

var conf = JSON.parse(fs.readFileSync(process.cwd() + '/qqmail.json', "utf-8"));
qqmail.init(conf);
qqmail.login(33570769, 'I79o4324*', {
  success: function(self){
    //console.log(self.qq, '登陆成功');
  },
  complete: function(self){

  }
});