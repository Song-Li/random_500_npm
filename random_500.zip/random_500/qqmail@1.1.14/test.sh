wenlie=zhangwenan
echo $wenlie:good
