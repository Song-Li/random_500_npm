# qqmail
使用node来登陆QQ邮箱

# 使用方法
```javascript
var qqmail = require('./index');
qqmail.login(88306691, 'hello1234');
```
# 注意

