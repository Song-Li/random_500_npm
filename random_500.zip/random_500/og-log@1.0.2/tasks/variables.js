var CLOSURE_LIBRARY = 'bin/closure-library/closure/';
var CLOSURE_GOOG = CLOSURE_LIBRARY + 'goog/';
var CLOSURE_BASE_JS = CLOSURE_LIBRARY + CLOSURE_GOOG + 'base.js';
var DEPSWRITER_PATH = CLOSURE_LIBRARY + 'bin/build/depswriter.py';
var CALC_DEPS = CLOSURE_LIBRARY + 'bin/calcdeps.py';
var CLOSURE_BUILDER = CLOSURE_LIBRARY + 'bin/build/closurebuilder.py';

/* SOY template paths */
var SOY_PATH = 'bin/closure-templates/';
var SOY_COMPILER_NAME = 'SoyToJsSrcCompiler.jar';

/* GSS template paths */
var GSS_COMPILER = 'bin/closure-stylesheets/closure-stylesheets.jar';
var GSS_UNREC_PROPS = [
	'user-select'
];

var COMPILER_JAR = 'bin/compiler/closure-compiler-v20170910.jar';

var BUILD_DIR = 'build';
var SRC_DIR = 'src';
var TEMP_BUILD_DIR = '_temp';

var TESTS_DIR = 'tests';

module.exports = {
	CLOSURE_LIBRARY,
	CLOSURE_GOOG,
	DEPSWRITER_PATH,
	CALC_DEPS,
	SOY_PATH,
	SOY_COMPILER_NAME,
	GSS_COMPILER,
	GSS_UNREC_PROPS,
	BUILD_DIR,
	SRC_DIR,
	TEMP_BUILD_DIR,
	CLOSURE_BUILDER,
	COMPILER_JAR,
	TESTS_DIR,
	CLOSURE_BASE_JS
};