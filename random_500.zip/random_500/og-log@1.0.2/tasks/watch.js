const {
	CLOSURE_LIBRARY,
	CLOSURE_GOOG,
	DEPSWRITER_PATH,
	SOY_PATH,
	SOY_COMPILER_NAME,
	GSS_COMPILER,
	GSS_UNREC_PROPS,
	BUILD_DIR
} = require('./variables.js');

const spawn = require('child_process').spawn;
const path = require('path');

const chokidar = require('chokidar');
const notifier = require('node-notifier');
const _ = require('underscore');

var watchers_ = {};
var EXTENSTIONS_WATCHERS = {
	"js": _.debounce(function(){
		var deps_process = spawn(DEPSWRITER_PATH, [
			"--root_with_prefix=./src ../../../../src",
			`--output_file=${BUILD_DIR}/dev/deps.js`
		], {
			cwd: process.cwd()
		});
		deps_process.stderr.on('data', (data) => {
		  console.log(`[JS]: stderr: ${data}`);
		});
		deps_process.on('close', function(code){
			console.log('[JS]: finished');
			notifier.notify({
				title: 'Javascript Build',
				message: 'Build finished with code ' + code
			})
		});
	}, 50),
	"soy": _.debounce(function(){
		var all_soy_files = getFileListFromWatched(watchers_['soy'].getWatched(), 'soy');
		// java -jar ./bin/soy/SoyToJsSrcCompiler.jar --cssHandlingScheme goog --srcs ./src/og.Logger/logger_templates.soy --outputPathFormat ./a.js --shouldProvideRequireSoyNamespaces
		var soy_compiler = spawn('java', [
			`-jar`, `${SOY_PATH}${SOY_COMPILER_NAME}`,
			`--cssHandlingScheme`, `goog`,
            `--shouldProvideRequireSoyNamespaces`,
			`--srcs`, all_soy_files.map(function(file, i, array){
				return i == array.length - 1 ? `${path.relative(process.cwd(), file)}` : `${path.relative(process.cwd(), file)},`
			}).join(''),
			`--outputPathFormat`, `${BUILD_DIR}/dev/templates.js`
		], {
			cwd: process.cwd()
		});
		soy_compiler.stderr.on('data', (data) => {
		  console.log(`[SOY] stderr: ${data}`);
		});
		soy_compiler.on('close', function(code){
			console.log('[SOY]: finished');
			notifier.notify({
				title: 'SOY Build',
				message: 'Build finished with code ' + code
			})
		});

	}, 50),
	"gss": function(){
		var all_gss_files = getFileListFromWatched(watchers_['gss'].getWatched(), 'gss');
		// java -jar ./closure-stylesheets.jar --css-renaming-prefix og --rename CLOSURE --output-renaming-map-format CLOSURE_COMPILED --output-renaming-map ./aa.json ./style.gss ./style2.gss
		var _errorStd = '';
		var gss_compiler = spawn('java', [
			'-jar', GSS_COMPILER,
			'--rename', 'CLOSURE',
			'--output-renaming-map-format', 'CLOSURE_COMPILED',
			'--output-renaming-map', `${BUILD_DIR}/dev/css_rename_map.js`,
			'--output-file', `${BUILD_DIR}/dev/styles.css`,
			'--allowed-unrecognized-property', `${GSS_UNREC_PROPS.join(' ')}`,
			...all_gss_files
		], {
			cwd: process.cwd()
		});
		gss_compiler.stderr.on('data', (data) => {
		  	_errorStd += data;
		});
		gss_compiler.on('close', function(code){
			if (code === 0) {
				console.log('[GSS]: finished');
				notifier.notify({
					title: 'GSS Build',
					message: 'Build finished with code ' + code
				})
			} else {
				console.log('[GSS ERROR]: ', _errorStd);
				notifier.notify({
					title: 'GSS Build ERROR',
					message: _errorStd
				})
			}
			
		});
	}
}

var getFileListFromWatched = function(watched_obj, file_extension){
	var _list = [];
	_.each(watched_obj, function(file_list, path_string){
		_.each(file_list, function(file){
			var full_file_path = path.join(path_string, file);
			var parsed_path = path.parse(full_file_path);
			if (parsed_path.ext == `.${file_extension}`) {
				_list.push(full_file_path);
			}
		});
	});
	return _list;
}

var addWatcher = function(file_extension, callback){
	if (watchers_.hasOwnProperty(file_extension)) {
		throw new Error(`Already watching ${file_extension} format`);
		return;
	}
	var watcher;

	watcher = watchers_[file_extension] = chokidar.watch(`./src/**/*.${file_extension}`);
	watcher.on('ready', _onWatcherReady.bind(null, file_extension));
	watcher.on('add', callback.bind(null, 'add'));
	watcher.on('unlink', callback.bind(null, 'unlink'));
	watcher.on('change', callback.bind(null, 'change'));
}

var _onWatcherReady = function(watcher_type){
	 console.log(`Watcher ${watcher_type} ready`);
}

_.each(EXTENSTIONS_WATCHERS, function(val, key, obj){
	addWatcher(key, val);
})