const {
  CLOSURE_LIBRARY,
  CLOSURE_GOOG,
  DEPSWRITER_PATH,
  SOY_PATH,
  SOY_COMPILER_NAME,
  GSS_COMPILER,
  GSS_UNREC_PROPS,
  BUILD_DIR,
  SRC_DIR,
  TEMP_BUILD_DIR,
  CLOSURE_BUILDER,
  COMPILER_JAR
} = require('./variables.js');

const spawn = require('child_process').spawn;
const path = require('path');
const fs = require('fs');

const glob = require('glob');
const _ = require('underscore');

var args = require('minimist')(process.argv.slice(2))
console.log(args["build"]);
// if (args[0]) {
    const PRODUCTION_BUILD = args["build"].toLowerCase() == 'production' ? true : false;
    const DEVELOPER_BUILD = args["build"].toLowerCase() == 'develop' ? true : false;
// } else {
    // const PRODUCTION_BUILD = false;
    // const DEVELOPER_BUILD = true;
// }
/* minified or not css styles */
// if (args["css_min"]) {
//     const MINIFY_CSS = true;
// } else {
//     const MINIFY_CSS = false;
// }

// if (args["css_separate"]) {
//     const CSS_SEPARATE = true;
// } else {
//     const CSS_SEPARATE = false;
// }

var buildGSS = function(temp_dir_path){
    return new Promise(function(resolve, reject){
        glob(`${SRC_DIR}/**/*.gss`, function(err, files){
            var all_gss_files = files,
                _errorStd = '',
                _stdOut = '';
            var gss_compiler = spawn('java', [
                '-jar', GSS_COMPILER,
                '--allowed-unrecognized-property', `${GSS_UNREC_PROPS.join(' ')}`,

                ...(function(){
                    if (PRODUCTION_BUILD) {
                        return [
                            '--rename', 'CLOSURE',
                            '--output-renaming-map-format', 'CLOSURE_COMPILED',
                            '--output-renaming-map', `${temp_dir_path}/css_rename_map.js`
                        ]
                    } else {
                        return [];
                    }
                })(),

                ...all_gss_files
            ], {
                cwd: process.cwd()
            });
            gss_compiler.stdout.on('data', function(data){
                _stdOut += data;
            });
            gss_compiler.stderr.on('data', (data) => {
                _errorStd += data;
            });
            gss_compiler.on('close', function(code){
                if (code === 0) {
                    console.log('[GSS]: finished');
                    fs.writeFile(`${temp_dir_path}/styles.js`, wrapGSS(_stdOut), function(){
                        resolve([`${temp_dir_path}/styles.js`, `${temp_dir_path}/css_rename_map.js`]);
                    });
                } else {
                    console.log('[GSS ERROR]: ', _errorStd);
                    reject(_errorStd);
                }
              
            });
        });
    });
}

var buildSoy = function(temp_dir_path){
    return new Promise(function(resolve, reject){
        glob(`${SRC_DIR}/**/*.soy`, function(err, files){
            var all_soy_files = files,
                _errorStd;
            var soy_compiler = spawn('java', [
                `-jar`, `${SOY_PATH}${SOY_COMPILER_NAME}`,
                `--cssHandlingScheme`, `goog`,
                `--shouldProvideRequireSoyNamespaces`,
                `--srcs`, all_soy_files.map(function(file, i, array){
                    return i == array.length - 1 
                                    ? `${path.relative(process.cwd(), file)}` 
                                    : `${path.relative(process.cwd(), file)},`
                }).join(''),
                `--outputPathFormat`, `${temp_dir_path}/{INPUT_FILE_NAME}.js`
            ], {
                cwd: process.cwd()
            });
            soy_compiler.stderr.on('data', (data) => {
                _errorStd += data;
            });
            soy_compiler.on('close', function(code){
                if (code === 0) {
                    resolve([`${temp_dir_path}/templates.js`]);
                } else {
                    reject(_errorStd);
                }
                console.log('[SOY]: finished');
            });
        })
    });
}

var buildJS = function(gss_paths, soy_paths, temp_dir){
    // var READFILE_PROMS = [];
    // READFILE_PROMS.push(readFile(gss_paths[0], wrapGSS));
    // READFILE_PROMS.push(readFile(gss_paths[1]));
    // READFILE_PROMS.push(readFile(soy_paths[0]));
    // 
    // var JS_CODE = [];
    return new Promise(function(resolve, reject){
        var closure_builder = spawn(
            CLOSURE_BUILDER, [
                `${CLOSURE_BUILDER}`,
                '--namespace', 'og',
                '--root', SRC_DIR,
                '--root', path.resolve(CLOSURE_LIBRARY, '../'),
                '--root', `${temp_dir}`,
                '--output_mode', 'compiled',
                '--compiler_jar', COMPILER_JAR,
                '--compiler_flags', '--generate_exports',
                '--compiler_flags', `--js ${path.join(temp_dir, 'styles.js')}`,

                ...(function(){
                    if (PRODUCTION_BUILD) {
                        return [
                            '--compiler_flags', '--compilation_level=ADVANCED',
                            '--compiler_flags', `--js ${path.join(temp_dir, 'css_rename_map.js')}`,
                            '--compiler_flags', '--assume_function_wrapper',
                            '--compiler_flags', `--output_wrapper_file ${SRC_DIR}/function_wrapper.js`,
                        ]
                    } else {
                        return [
                            '--compiler_flags', '--formatting=PRETTY_PRINT'
                        ]
                    }
                })()
                
            ]
        );
        var closure_stdout = '',
            closure_stderr = '';
        closure_builder.stdout.on('data', function(data){closure_stdout += data;});
        closure_builder.stderr.on('data', function(data){closure_stderr += data;});
        closure_builder.on('close', function(code){
            if (code === 0) {
                resolve(closure_stdout);
            } else {
                reject(closure_stderr);
            }
        });
        // glob(`${SRC_DIR}/**/*.js`, function(err, files){
        //   getDeps().then(function(array_of_paths){
        //     _.each(_.unique([...array_of_paths, ...files]), function(val){
        //       READFILE_PROMS.push(readFile(val));
        //     });
        //     Promise.all(READFILE_PROMS).then(function(promise_responses){
        //       _.each(promise_responses, function(file_content){
        //         JS_CODE.push({src: file_content.toString()});
        //       });
    
        //       console.log('Finished reading files');
        //       console.log('Start compiling');
        
        //       // fs.writeFileSync(`${temp_dir}/concat.js`, JS_CODE);
        //       console.log(compiler({
        //         jsCode: JS_CODE,
        //         compilationLevel: 'ADVANCED',
        //         'generateExports': true,
        
        //       }));
        //     });
        //   })
        // });
    });
}

var readFile = function(path, post_process){
    return new Promise(function(resolve, reject){
        fs.readFile(path, function(error, data){
            if (error) {
                reject(error);
            } else {
                if (post_process) {
                    resolve(post_process(data));
                } else {
                    resolve(data.toString());
                }
            }
        })
    })
}

var getDeps = function(){
    // closure-library/closure/bin/build/closurebuilder.py --namespace og --root ./src --root ./closure-library/
    return new Promise(function(resolve, reject){
        var deps_proccess = spawn('python', [
            `${CLOSURE_BUILDER}`,
            '--namespace', 'og',
            '--root', SRC_DIR,
            '--root', './closure-library/'
        ], {
            cwd: process.cwd()
        });
        var DEPS_STDOUT = '', DEPS_STDERR = '';
        deps_proccess.stdout.on('data', function(data){
            DEPS_STDOUT += data;
        });

        deps_proccess.stderr.on('data', function(data){
            DEPS_STDERR += data
        });

        deps_proccess.on('close', function(code){
            if (code === 0) {
                DEPS_STDOUT = DEPS_STDOUT.split('\n');
                DEPS_STDOUT = _.filter(DEPS_STDOUT, function(path){
                    return path.length && path.indexOf('closure-library/closure/') === 0
                });
                resolve(DEPS_STDOUT);
            } else {
                reject(DEPS_STDERR);
            }
        })

    });
}

var wrapGSS = function(gss){
    return `
        goog.require('goog.dom');
        goog.dom.appendChild(
          document.head, 
          goog.dom.createDom(goog.dom.TagName.STYLE, null, "${gss.toString().replace(/\"/gm, '\'')}")
        );
    `;
}

var startBuild = function(){
    // Make a temp directory for build files
    var temp_dir = fs.mkdtempSync(`./${TEMP_BUILD_DIR}`);
    var gss_promise = buildGSS(temp_dir);
    var soy_promise = buildSoy(temp_dir);

    Promise.all([gss_promise, soy_promise]).then(function(result){
        var gss_paths = result[0],
            soy_paths = result[1];
        console.log('- Starting build task ...');
        var js_promise = buildJS(gss_paths, soy_paths, temp_dir);
        js_promise.then(function(response){
            console.log('- Build finished, cleaning temp directories ... ');
            var temp_files = fs.readdirSync(path.join(process.cwd(), temp_dir));
            _.each(temp_files, function(path_){
                fs.unlinkSync(path.join(process.cwd(), temp_dir, path_));
            });
            fs.rmdirSync(path.join(process.cwd(), temp_dir));
            var result_js_file_name = PRODUCTION_BUILD ? 'build.prod.min.js' : 'build.dev.js';
            console.log(`- Writing js to ${path.join(process.cwd(), BUILD_DIR, result_js_file_name)}`)
            fs.writeFileSync(path.join(process.cwd(), BUILD_DIR, result_js_file_name), response);
        })
    })

}

startBuild();