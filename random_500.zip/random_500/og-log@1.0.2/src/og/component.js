goog.provide('og.component');

/**
 * Namespace
 * @const
 */
og.component = {};

// goog.exportSymbol('og.component.TYPE', og.component.TYPE);