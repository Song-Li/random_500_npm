goog.provide('og.component.Stack');

goog.require('og.component.OPTION');
goog.require('og.component.Component');

goog.require('goog.dom');
goog.require('goog.style');
goog.require('goog.events');
goog.require('goog.object');
goog.require('goog.array');
goog.require('goog.ui.Zippy');

goog.require('og.templates.component.Stack');

/**
 * @constructor
 * @extends {og.component.Component}
 * @param {Object} [varname] [description]
 */
og.component.Stack = function(opt_options){
	var self = this;
	opt_options = opt_options || {};

	self.options = {};
	self.options[og.component.OPTION.LEFT_START_VALUE] = 
		goog.isDef(opt_options[og.component.OPTION.LEFT_START_VALUE])
			? opt_options[og.component.OPTION.LEFT_START_VALUE]
			: 'Stack ' + goog.getUid(self);

	self.options[og.component.OPTION.INITIAL_VALUES] = 
		goog.isDef(opt_options[og.component.OPTION.INITIAL_VALUES])
			? opt_options[og.component.OPTION.INITIAL_VALUES]
			: [];

	self.options[og.component.OPTION.FORMATTER] = 
		goog.isDef(opt_options[og.component.OPTION.FORMATTER])
			? opt_options[og.component.OPTION.FORMATTER]
			: self.formatter_;

	self.options[og.component.OPTION.MAX_HEIGHT] = 
		goog.isDef(opt_options[og.component.OPTION.MAX_HEIGHT])
			? opt_options[og.component.OPTION.MAX_HEIGHT]
			: 200;

	self.options[og.component.OPTION.TEXT_ALIGN] = 
		goog.isDef(opt_options[og.component.OPTION.TEXT_ALIGN])
			? opt_options[og.component.OPTION.TEXT_ALIGN]
			: 'right';
	

	self.templates_ = og.templates.component.Stack;

	self.onZippyToggle_ = goog.bind(self.onZippyToggle_, self);

	self.values_ = goog.array.clone(
		self.options[og.component.OPTION.INITIAL_VALUES]
	);

	self.el_ = self.generateContainer_();
	
	/* Header DOM Element */
	self.header_ = 
		goog.dom.getElementByClass(
			goog.getCssName('header-wrapper'),
			self.getContainer()
		);

	/* Entries wrapper DOM Element */
	self.entriesWrapperEl = 
		goog.dom.getElementByClass(
			goog.getCssName('expandable-content-wrapper'),
			self.getContainer()
		);
	
	/* Entries DOM Element */
	self.entriesEl_ = 
		goog.dom.getElementByClass(
			goog.getCssName('expandable-content'),
			self.getContainer()
		);

	self.zippy = new goog.ui.Zippy(self.header_, self.entriesEl_);
}
goog.inherits(og.component.Stack, og.component.Component);
goog.exportSymbol('og.component.Stack', og.component.Stack);

og.component.Stack.prototype.onAdd = function(){
	var self = this;
	goog.events.listen(
		self.zippy, 
		goog.ui.Zippy.Events.TOGGLE, 
		self.onZippyToggle_
	);
}

og.component.Stack.prototype.onRemove = function(){
	var self = this;
	goog.events.unlisten(
		self.zippy, 
		goog.ui.Zippy.Events.TOGGLE, 
		self.onZippyToggle_
	);
	goog.dom.removeNode(self.getContainer());
}

og.component.Stack.prototype.getValues = function(){
	return this.values_;
};

og.component.Stack.prototype.getLength = function(){
	var values = this.getValues();
	return values.length;
};

og.component.Stack.prototype.getHeaderContainer = function(){
	return this.header_;
}

og.component.Stack.prototype.getEntriesContainer = function(){
	return this.entriesEl_;
}

og.component.Stack.prototype.generateContainer_ = function(){
	var self = this;
	return soy.renderAsFragment(
		self.templates_.wrapper, 
		{
			options: self.options,
			constants: og.component.OPTION
		}
	);
};

og.component.Stack.prototype.setLabel = function(label){
	var self = this;
	var headerElement = self.getHeaderContainer();
	var headerTextElement = goog.dom.getElementByClass(
		goog.getCssName('header'),
		headerElement
	);
	goog.dom.setTextContent(headerTextElement, label);
};

og.component.Stack.prototype.setTextAlign = function(text_align){
	var self = this;
	var containerElement = self.getContainer();
	if (text_align === 'left' || !text_align) {
		goog.dom.classlist
			.remove(containerElement, goog.getCssName('right-align'));
	} else if (text_align === 'right') {
		goog.dom.classlist
			.add(containerElement, goog.getCssName('right-align'));
	}
};

og.component.Stack.prototype.setMaxHeight = function(max_height){
	var self = this;
	max_height = max_height|0;
	goog.style.setStyle(self.entriesWrapperEl, 'max-height', max_height);
};

/**
 * Add a value or an array of values to the logger
 * @param  {String|Array[String]} value_or_array - String or an array of strings
 * @export
 * @return {undefined}
 */
og.component.Stack.prototype.insert = function(value_or_array) {
	var self = this;
	if ((self.entriesWrapperEl.scrollHeight - self.entriesWrapperEl.scrollTop) === self.entriesWrapperEl.clientHeight) {
		self.insert_(value_or_array);
		self.entriesWrapperEl.scrollTop = self.entriesWrapperEl.scrollHeight;
	} else {
		self.insert_(value_or_array);
	}
	return self;
};

/**
 * Helper function to insert method.
 * @private
 * @param  {String|Array[String]} value_or_array - String or an array of strings
 * @return {undefined}
 */
og.component.Stack.prototype.insert_ = function(value_or_array){
	var self = this;
	if (goog.isArray(value_or_array)) {
		goog.array.forEach(value_or_array, function(value){
			self.appendValue_(value);
		});
	} else {
		self.appendValue_(value_or_array);
	}
}

/**
 * Appends a log value to the logger
 * @param  {String} value - Log entry value
 * @return {undefined}
 */
og.component.Stack.prototype.appendValue_ = function(value){
	var self = this;
	self.values_.push(value);

	var formatter = self.getFormatter();
	value = formatter(value);
	var outerElement = soy.renderAsFragment(
		self.templates_.log_entry,
		{text: value}
	);
	
	goog.dom.appendChild(self.entriesEl_, outerElement);

	if (!self.zippy.isExpanded()) {
		goog.dom.classlist.add(self.el_, goog.getCssName('new-entry'));
	}
}

/**
 * Clears the container of the logger
 * @export
 * @return {this}
 */
og.component.Stack.prototype.clear = function(){
	var self = this;
	self.values_ = [];
	goog.dom.removeChildren(self.entriesEl_);
	self.entriesWrapperEl.scrollTop = 0;
	return self;
}

/**
 * An event handler for zippy toggle event
 * @return {undefined}
 */
og.component.Stack.prototype.onZippyToggle_ = function(){
	var self = this;
	if (self.zippy.isExpanded()) {
		goog.dom.classlist.remove(self.el_, goog.getCssName('new-entry'));
		self.entriesWrapperEl.scrollTop = self.entriesWrapperEl.scrollHeight;
	}
}

