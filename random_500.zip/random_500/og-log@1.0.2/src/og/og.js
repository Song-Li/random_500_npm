goog.provide('og');

goog.require('goog.string.StringBuffer');
goog.require('goog.soy');

// if (COMPILED) {
	goog.require('og.Logger');
    goog.require('og.component');
	goog.require('og.component.TYPE');
	goog.require('og.component.Component');
	goog.require('og.component.Static');
	goog.require('og.component.Interval');
	goog.require('og.component.Stack');
// }

og.VERSION = '1.0.2';
og.STORAGE_PROP = 'og-data';