goog.provide('og.test.og');
describe("Version check", function(){
	it("should be correct version", function(){
		expect(og.VERSION).toBe('0.0.5');
	})
})