goog.provide('og.test.component');

describe("Check for accessability of all known components", function(){
	it("Interval component should be defined", function(){
		expect(og.component.Interval).toBeDefined();
	})
	it("Stack component should be defined", function(){
		expect(og.component.Stack).toBeDefined();
	})
	it("Static component should be defined", function(){
		expect(og.component.Static).toBeDefined();
	})
})