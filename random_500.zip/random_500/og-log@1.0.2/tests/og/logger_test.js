goog.provide('og.test.Logger');

describe("Logger", function(){
	var logger_instance;
	var static_component;

	beforeEach(function(){
		logger_instance = new og.Logger();
		static_component = new og.component.Static();
	});

	afterEach(function(){
		logger_instance.destroy();
		logger_instance = false;
		static_component = false;
	});

	it("Should contain no components after initialization", function(){
		var components = logger_instance.getComponents();
		expect(components).toEqual([]);
	});

	describe("Adding a component", function(){
		it("should call onAdd method on the adding component", function(){
			spyOn(static_component, 'onAdd').and.callThrough();
	
			logger_instance.addComponent(static_component);
			expect(static_component.onAdd).toHaveBeenCalled();
		});

		it("should return the component when calling addComponent", function(){
			var added_component = logger_instance.addComponent(static_component);
			expect(added_component).toEqual(static_component);
		});

		it("should not add the same component twice", function(){
			var component;
			spyOn(static_component, 'onAdd').and.callThrough();
			logger_instance.addComponent(static_component);
			component = logger_instance.addComponent(static_component);
			expect(static_component.onAdd).toHaveBeenCalledTimes(1);
			expect(component).toBe(false);
		});

		it("should add an item in array of components", function(){
			logger_instance.addComponent(static_component);
			var components = logger_instance.getComponents();
			expect(components.length).toEqual(1);
		});

		it("should actually add a component in the dom", function(){
			var logger_container = logger_instance.getContainer();
			logger_instance.addComponent(static_component);
			var component_container = static_component.getContainer();
			expect(logger_container.contains(component_container)).toBe(true);
		})
	});

	describe("Removing component", function(){
		beforeEach(function(){
			// Add a component first
			logger_instance.addComponent(static_component);
		});

		it("should call onRemove method on the adding component", function(){
			spyOn(static_component, 'onRemove').and.callThrough();

			logger_instance.removeComponent(static_component);
			expect(static_component.onRemove).toHaveBeenCalled();
		});

		it("should return correct value when calling removeComponent and should not remove the same component twice", function(){
			var remove_result;

			remove_result = logger_instance.removeComponent(static_component);
			expect(remove_result).toBe(true);

			remove_result = logger_instance.removeComponent(static_component);
			expect(remove_result).toBe(false);
		});

		it("should remove and item from array of components", function(){
			var components;
			logger_instance.removeComponent(static_component);
			components = logger_instance.getComponents();
			expect(components.length).toEqual(0);
		});

		it("should actually remove the component from the dom", function(){
			var logger_container = logger_instance.getContainer();
			var component_container = static_component.getContainer();
			logger_instance.removeComponent(static_component);
			expect(logger_container.contains(component_container)).toBe(false);
		});
	});


});