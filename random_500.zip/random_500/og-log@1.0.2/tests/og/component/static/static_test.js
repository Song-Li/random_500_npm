goog.provide('og.test.component.Static');


describe("Static component", function(){
	var logger_instance;
	beforeEach(function(){
		logger_instance = new og.Logger();
	});
	afterEach(function(){
		logger_instance.destroy();
		logger_instance = false;
	});

	it("should initialize with default options", function(){
		var static_component = new og.component.Static();
		var label_container = static_component.getLabelContainer();
		var value_container = static_component.getValueContainer();
		expect(label_container.textContent).toEqual("");
		expect(value_container.textContent).toEqual("");

		var default_formatter = static_component.getFormatter();
		expect(default_formatter("test string")).toEqual("test string");
	});

	it("should initialize with custom options", function(){
		var static_component = new og.component.Static({
			label: 'Test Label',
			value: 'Test Value',
			formatter: function(input){ return input + input; }
		});
		var label_container = static_component.getLabelContainer();
		var value_container = static_component.getValueContainer();
		expect(label_container.textContent).toEqual("Test Label");
		expect(value_container.textContent).toEqual("Test Value");

		var formatter = static_component.getFormatter();
		expect(formatter("test")).toEqual("testtest");
	});

	it("should correctly call the update function", function(){
		var static_component = new og.component.Static();
		var label_container = static_component.getLabelContainer();
		var value_container = static_component.getValueContainer();

		static_component.update('updated value');
		expect(label_container.textContent).toEqual("");
		expect(value_container.textContent).toEqual("updated value");

		static_component.update(null, 'updated label');
		expect(label_container.textContent).toEqual("updated label");
		expect(value_container.textContent).toEqual("updated value");
	
		static_component.update('new value', null);
		expect(label_container.textContent).toEqual("updated label");
		expect(value_container.textContent).toEqual("new value");

		static_component.update(null, null);
		expect(label_container.textContent).toEqual("updated label");
		expect(value_container.textContent).toEqual("new value");

		static_component.update();
		expect(label_container.textContent).toEqual("updated label");
		expect(value_container.textContent).toEqual("new value");
	});

	it("should correctly call formatter", function(){
		var static_component = new og.component.Static({
			label: 'label',
			formatter: function(input){ return input + 1; }
		});
		var value_container = static_component.getValueContainer();

		static_component.update('value');
		expect(value_container.textContent).toEqual("value1");

		static_component.update(1);
		expect(value_container.textContent).toEqual('2');

		static_component.update({object: 'object'});
		expect(value_container.textContent).toEqual('[object Object]1');
	});

	it('should correctly change formatter', function(){
		var static_component = new og.component.Static({
			formatter: function(input){ return input; }
		});
		var value_container = static_component.getValueContainer();

		static_component.update('value');
		expect(value_container.textContent).toEqual("value");

		static_component.setFormatter(function(input){
			return JSON.stringify(input);
		});

		var value_object = {
			a:1,
			b:2,
			c:3
		};

		static_component.update(value_object);
		expect(value_container.textContent).toEqual(JSON.stringify(value_object));
	});

	it("should correctly add itself to logger", function(){
		var static_component = new og.component.Static({
			formatter: function(input){ return input; }
		});
		var component_container = static_component.getContainer();
		var logger_container = logger_instance.getContainer();

		static_component.addTo(logger_instance);
		expect(logger_container.contains(component_container)).toBe(true);
	});

	it("should correctly remove itself to logger", function(){
		var static_component = new og.component.Static({
			formatter: function(input){ return input; }
		});
		var component_container = static_component.getContainer();
		var logger_container = logger_instance.getContainer();

		static_component.addTo(logger_instance);
		static_component.removeFrom(logger_instance);
		expect(logger_container.contains(component_container)).toBe(false);
	});
});
