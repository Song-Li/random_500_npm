goog.provide('og.test.component.Stack');

describe("Stack component", function(){
	var logger_instance;
	beforeEach(function(){
		logger_instance = new og.Logger();
	});
	afterEach(function(){
		logger_instance.destroy();
		logger_instance = false;
	});

	it("should initialize itself with default options", function(){
		var stack_component = new og.component.Stack();
		var component_values = stack_component.getValues();
		var header_container = stack_component.getHeaderContainer();

		stack_component.addTo(logger_instance);

		expect(component_values.length).toBe(0);
		expect(header_container.textContent).toMatch("Stack");

	});

	it("should initialize with custom options", function(){
		var initial_values = [1,2,3,4,5];
		var component_label = "Custom label";
		var component_formatter = function(input) { return input+1; };
		var maxHeight = 500;
		var stack_component = new og.component.Stack({
			label: component_label,
			initialValues: initial_values,
			formatter: component_formatter,
			maxHeight: maxHeight,
			textAlign: 'right'
		});
		console.log(stack_component);
		expect(stack_component.getValues()).toEqual(initial_values);
		expect(stack_component.getHeaderContainer().textContent).toEqual(component_label);
		expect(stack_component.getFormatter()(1)).toEqual(2);
		expect(stack_component.getFormatter()(2)).toEqual(3);

		var expandable_content_wrapper = stack_component.getEntriesContainer().parentElement;
		expect(expandable_content_wrapper.style.maxHeight).toMatch(maxHeight+"");

		expect(stack_component.getContainer().className).toMatch('right-align');
	});

	it("should apply zippy to component container", function(){
		var stack_component = new og.component.Stack();
		var header_container = stack_component.getHeaderContainer();
		
		expect(header_container.className).toMatch('zippy-header');
	});

	xit("should correctly call the update function", function(){});
	xit("should correctly call formatter", function(){});
	xit('should correctly change formatter', function(){});
	xit("should correctly add itself to logger", function(){});
	xit("should correctly remove itself to logger", function(){});
});
