goog.provide('og.test.component.component');
describe("Component interface", function(){
	it("should be assessable from window", function(){
		expect(og.component.Component).toBeDefined();
	});
	it("should have methods defined", function(){
		expect(og.component.Component.prototype.onAdd).toBeDefined();
		expect(og.component.Component.prototype.onRemove).toBeDefined();
		expect(og.component.Component.prototype.update).toBeDefined();
		expect(og.component.Component.prototype.getFormatter).toBeDefined();
		expect(og.component.Component.prototype.getContainer).toBeDefined();
		expect(og.component.Component.prototype.addTo).toBeDefined();
		expect(og.component.Component.prototype.removeFrom).toBeDefined();
	})
})