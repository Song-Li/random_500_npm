const RequestStore = require('../store/request');
/**
 * Built the store in order to the .
 * @return {RequestStore} - An instanciated application store.
 */
module.exports = new RequestStore();
