/**
 * Application domain gestion.
 * @type {Object}
 */
module.exports = {
	container: require('./container')
};
