module.exports = {
  date: require('./date'),
  email: require('./email'),
  number: require('./number'),
  stringLength: require('./string-length'),
  validate: require('./validate')
};
