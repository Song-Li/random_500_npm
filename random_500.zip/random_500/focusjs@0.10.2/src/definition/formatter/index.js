module.exports = {
    number: require('./number')
};
