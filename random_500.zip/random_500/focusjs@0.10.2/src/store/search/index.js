module.exports = {
  QuickSearch: require('./quick-search'),
  AdvancedSearch: require('./advanced-search')
};
