Utilitaires de focus
