module.exports = {
	string: require('./string'),
	object: require('./object'),
	url: require('./url')
};
