const MessageStore = require('../store/message');
/**
 * Built the store in order to the .
 * @return {MessageStore} - An instanciated reference store.
 */
module.exports = new MessageStore();
