Le routeur utilise le routeur de backbone. 
