Exceptions

In focus, there is different types of Exceptions:
- ArgumentInvalid
- FocusException 
