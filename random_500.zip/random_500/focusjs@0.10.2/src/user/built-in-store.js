var UserStore = require('../store/user');
module.exports = new UserStore();
