module.exports = {
    login: 'login',
    password: 'password'
};
