module.exports = {
  id: 'id',
  provider: 'provider',
  displayName: 'displayName',
  culture: 'culture',
  email: 'email',
  photo: 'photo',
  firstName: 'firstName',
  lastName: 'lastName'
};
