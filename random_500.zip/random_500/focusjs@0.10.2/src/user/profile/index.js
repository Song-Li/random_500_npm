module.exports = {
  definition: require('./definition')
};
