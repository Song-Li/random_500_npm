var handlers = [{
  callback: function(fragment) {},
  route: /^(?:\?([\s\S]*))?$/
}, {
  callback: function() {},
  //route: /^administration/security/roleList(?:\?([\s\S]*))?$/
}, {
  callback: function() {},
  route: /^administration/audit/diagnostic(?:\?([\s\S]*))?$/
}, {
  callback: function() {},
  route: /^route1(?:\?([\s\S]*))?$/
}, {
  callback: function() {},
  route: /^administration/audit/diagnosticd(?:\?([\s\S]*))?$/
}, {
  callback: function() {},
  route: /^pageSansMenu(?:\?([\s\S]*))?$/
}, {
  callback: function() {},
  route: /^pageSansMenu11(?:\?([\s\S]*))?$/
}, {
  callback: function() {},
  route: /^administration/other/other(?:\?([\s\S]*))?$/
}, {
  callback: function() {},
  route: /^ppppageSansMenu777(?:\?([\s\S]*))?$/
}, {
  callback: function() {},
  route: /^pppppppageSansMenu102121(?:\?([\s\S]*))?$/
}];

module.exports = handlers;